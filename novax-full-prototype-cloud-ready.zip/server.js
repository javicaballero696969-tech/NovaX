const express=require("express");
const Database=require("better-sqlite3");
const crypto=require("crypto");
const jwt=require("jsonwebtoken");
const path=require("path");

const app=express(), db=new Database("novax.db");
const PORT=process.env.PORT||3000, JWT_SECRET=process.env.JWT_SECRET||"change-this-secret-in-production";
app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS balances(
 user_id INTEGER,asset TEXT,amount REAL NOT NULL DEFAULT 0,PRIMARY KEY(user_id,asset),
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS trades(
 id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,side TEXT,asset TEXT,usd REAL,quantity REAL,price REAL,created_at TEXT,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const prices={BTC:104250,ETH:4240.18,SOL:238.44,XRP:2.87,BNB:812.36};

function hash(p){return crypto.scryptSync(p,"novax-salt",64).toString("hex")}
function auth(req,res,next){
  try{const h=req.headers.authorization||""; if(!h.startsWith("Bearer ")) throw 0;
    req.user=jwt.verify(h.slice(7),JWT_SECRET); next();
  }catch(e){res.status(401).json({error:"Authentication required"})}
}
function seedBalances(id){
  const ins=db.prepare("INSERT OR IGNORE INTO balances(user_id,asset,amount) VALUES(?,?,?)");
  const tx=db.transaction(()=>{ins.run(id,"USD",25000); for(const a of Object.keys(prices)) ins.run(id,a,0)});
  tx();
}
app.post("/api/register",(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase(), password=String(req.body.password||"");
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)||password.length<8) return res.status(400).json({error:"Use a valid email and a password of at least 8 characters."});
  try{
    const info=db.prepare("INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)").run(email,hash(password));
    seedBalances(info.lastInsertRowid);
    const token=jwt.sign({id:info.lastInsertRowid,email},JWT_SECRET,{expiresIn:"7d"});
    res.json({token,email});
  }catch(e){res.status(409).json({error:"An account with that email already exists."})}
});
app.post("/api/login",(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase(), password=String(req.body.password||"");
  const u=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(!u||hash(password)!==u.password_hash) return res.status(401).json({error:"Invalid email or password."});
  res.json({token:jwt.sign({id:u.id,email:u.email},JWT_SECRET,{expiresIn:"7d"}),email:u.email});
});
app.get("/api/me",auth,(req,res)=>res.json({email:req.user.email,id:req.user.id}));
app.get("/api/market",(req,res)=>{
  for(const a of Object.keys(prices)) prices[a]*=1+(Math.random()-.49)*.001;
  res.json({prices,updatedAt:new Date().toISOString()});
});
app.get("/api/portfolio",auth,(req,res)=>{
  const rows=db.prepare("SELECT asset,amount FROM balances WHERE user_id=?").all(req.user.id);
  res.json({balances:Object.fromEntries(rows.map(x=>[x.asset,x.amount])),prices});
});
app.post("/api/trade",auth,(req,res)=>{
  const side=req.body.side==="sell"?"sell":"buy", asset=req.body.asset;
  const usd=Number(req.body.usd), price=prices[asset], qty=usd/price;
  if(!prices[asset]||!Number.isFinite(usd)||usd<=0) return res.status(400).json({error:"Invalid trade."});
  const get=db.prepare("SELECT amount FROM balances WHERE user_id=? AND asset=?");
  const update=db.prepare("UPDATE balances SET amount=? WHERE user_id=? AND asset=?");
  const addTrade=db.prepare("INSERT INTO trades(user_id,side,asset,usd,quantity,price,created_at) VALUES(?,?,?,?,?,?,?)");
  const tx=db.transaction(()=>{
    const cash=get.get(req.user.id,"USD").amount, holding=get.get(req.user.id,asset).amount;
    if(side==="buy" && cash<usd) throw new Error("Insufficient USD balance.");
    if(side==="sell" && holding<qty) throw new Error("Insufficient asset balance.");
    update.run(side==="buy"?cash-usd:cash+usd,req.user.id,"USD");
    update.run(side==="buy"?holding+qty:holding-qty,req.user.id,asset);
    addTrade.run(req.user.id,side,asset,usd,qty,price,new Date().toISOString());
  });
  try{tx();res.json({ok:true,side,asset,usd,quantity:qty,price})}catch(e){res.status(400).json({error:e.message})}
});
app.get("/api/trades",auth,(req,res)=>res.json(db.prepare("SELECT side,asset,usd,quantity,price,created_at FROM trades WHERE user_id=? ORDER BY id DESC LIMIT 50").all(req.user.id)));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public/index.html")));
app.listen(PORT,()=>console.log(`NovaX running at http://localhost:${PORT}`));
