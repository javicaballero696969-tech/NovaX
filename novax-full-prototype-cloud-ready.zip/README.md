# NovaX V2 — Full-stack simulated exchange

## Run
1. Install Node.js 20+.
2. In this folder run: `npm install`
3. Run: `npm start`
4. Open: http://localhost:3000

## Included
- User registration/login
- Password hashing with Node crypto/scrypt
- JWT authentication
- SQLite database
- Persistent simulated USD + crypto balances
- Simulated market-price API
- Buy/sell API with server-side balance validation
- Persistent trade history
- Responsive exchange dashboard

## Important
This is a development/simulation system. It has no real blockchain custody, deposits, withdrawals, fiat payments, KYC/AML, or real trading execution. Before production, replace the demo JWT secret, add HTTPS, rate limiting, CSRF protections where applicable, stronger secret management, audit logging, security review, and appropriate compliance/custody infrastructure.
